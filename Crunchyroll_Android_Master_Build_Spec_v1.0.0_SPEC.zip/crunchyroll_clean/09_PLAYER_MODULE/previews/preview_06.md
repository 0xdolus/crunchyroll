---
spec_version: 1.0.0
artifact_id: DOC-PREVIEW-06-2
owner: player
path: 09_PLAYER_MODULE/previews/preview_06.md
locked: true
last_reviewed: 2026-09-16
---
# Player Preview 06

HTML + PNG reference for overlay / state.
