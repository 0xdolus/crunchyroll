---
spec_version: 1.0.0
artifact_id: DOC-TEMPLATE-16
owner: process
path: templates/template_16.md
locked: true
last_reviewed: 2026-09-16
---
# Reusable Template 16

## Usage
Copy and fill for new contracts, screens, components, or reports.
