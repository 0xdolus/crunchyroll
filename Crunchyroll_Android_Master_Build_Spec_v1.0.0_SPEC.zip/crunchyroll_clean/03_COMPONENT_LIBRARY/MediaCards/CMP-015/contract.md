---
spec_version: 1.0.0
artifact_id: CMP-015-CONTRACT
entity_id: CMP-015
owner: component-library
path: 03_COMPONENT_LIBRARY/MediaCards/CMP-015/contract.md
locked: true
last_reviewed: 2026-09-16
---
# CMP-015 — contract

## Component Category
MediaCards

## File
contract.md

## Specification
Detailed contract / states / props / a11y / preview / usage for component CMP-015.

## Status
Draft — expand with concrete Compose signatures, state tables, and visual references.
