---
spec_version: 1.0.0
artifact_id: CMP-007-PROPS
entity_id: CMP-007
owner: component-library
path: 03_COMPONENT_LIBRARY/MediaCards/CMP-007/props.md
locked: true
last_reviewed: 2026-09-16
---
# CMP-007 — props

## Component Category
MediaCards

## File
props.md

## Specification
Detailed contract / states / props / a11y / preview / usage for component CMP-007.

## Status
Draft — expand with concrete Compose signatures, state tables, and visual references.
