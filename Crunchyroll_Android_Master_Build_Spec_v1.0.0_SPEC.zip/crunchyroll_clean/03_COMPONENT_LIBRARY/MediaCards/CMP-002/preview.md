---
spec_version: 1.0.0
artifact_id: CMP-002-PREVIEW
entity_id: CMP-002
owner: component-library
path: 03_COMPONENT_LIBRARY/MediaCards/CMP-002/preview.md
locked: true
last_reviewed: 2026-09-16
---
# CMP-002 — preview

## Component Category
MediaCards

## File
preview.md

## Specification
Detailed contract / states / props / a11y / preview / usage for component CMP-002.

## Status
Draft — expand with concrete Compose signatures, state tables, and visual references.
