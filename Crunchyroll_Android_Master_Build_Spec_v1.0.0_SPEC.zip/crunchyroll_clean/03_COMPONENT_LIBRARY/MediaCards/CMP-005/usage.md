---
spec_version: 1.0.0
artifact_id: CMP-005-USAGE
entity_id: CMP-005
owner: component-library
path: 03_COMPONENT_LIBRARY/MediaCards/CMP-005/usage.md
locked: true
last_reviewed: 2026-09-16
---
# CMP-005 — usage

## Component Category
MediaCards

## File
usage.md

## Specification
Detailed contract / states / props / a11y / preview / usage for component CMP-005.

## Status
Draft — expand with concrete Compose signatures, state tables, and visual references.
