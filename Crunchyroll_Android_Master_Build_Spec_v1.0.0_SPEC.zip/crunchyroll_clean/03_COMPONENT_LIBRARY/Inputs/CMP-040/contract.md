---
spec_version: 1.0.0
artifact_id: CMP-040-CONTRACT
entity_id: CMP-040
owner: component-library
path: 03_COMPONENT_LIBRARY/Inputs/CMP-040/contract.md
locked: true
last_reviewed: 2026-09-16
---
# CMP-040 — contract

## Component Category
Inputs

## File
contract.md

## Specification
Detailed contract / states / props / a11y / preview / usage for component CMP-040.

## Status
Draft — expand with concrete Compose signatures, state tables, and visual references.
