---
spec_version: 1.0.0
artifact_id: CMP-035-STATES
entity_id: CMP-035
owner: component-library
path: 03_COMPONENT_LIBRARY/Inputs/CMP-035/states.md
locked: true
last_reviewed: 2026-09-16
---
# CMP-035 — states

## Component Category
Inputs

## File
states.md

## Specification
Detailed contract / states / props / a11y / preview / usage for component CMP-035.

## Status
Draft — expand with concrete Compose signatures, state tables, and visual references.
