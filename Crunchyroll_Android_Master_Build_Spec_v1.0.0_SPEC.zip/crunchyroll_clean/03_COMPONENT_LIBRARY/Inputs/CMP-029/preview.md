---
spec_version: 1.0.0
artifact_id: CMP-029-PREVIEW
entity_id: CMP-029
owner: component-library
path: 03_COMPONENT_LIBRARY/Inputs/CMP-029/preview.md
locked: true
last_reviewed: 2026-09-16
---
# CMP-029 — preview

## Component Category
Inputs

## File
preview.md

## Specification
Detailed contract / states / props / a11y / preview / usage for component CMP-029.

## Status
Draft — expand with concrete Compose signatures, state tables, and visual references.
