---
spec_version: 1.0.0
artifact_id: CMP-031-PROPS
entity_id: CMP-031
owner: component-library
path: 03_COMPONENT_LIBRARY/Inputs/CMP-031/props.md
locked: true
last_reviewed: 2026-09-16
---
# CMP-031 — props

## Component Category
Inputs

## File
props.md

## Specification
Detailed contract / states / props / a11y / preview / usage for component CMP-031.

## Status
Draft — expand with concrete Compose signatures, state tables, and visual references.
