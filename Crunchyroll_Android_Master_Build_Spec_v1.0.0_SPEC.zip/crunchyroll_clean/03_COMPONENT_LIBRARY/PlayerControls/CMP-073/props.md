---
spec_version: 1.0.0
artifact_id: CMP-073-PROPS
entity_id: CMP-073
owner: component-library
path: 03_COMPONENT_LIBRARY/PlayerControls/CMP-073/props.md
locked: true
last_reviewed: 2026-09-16
---
# CMP-073 — props

## Component Category
PlayerControls

## File
props.md

## Specification
Detailed contract / states / props / a11y / preview / usage for component CMP-073.

## Status
Draft — expand with concrete Compose signatures, state tables, and visual references.
