package com.crunchyroll.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Shapes
import androidx.compose.ui.unit.dp

/**
 * Centralized shapes.
 * - 16dp for posters / cards
 * - 24dp for buttons
 * - Full for chips / pills
 */
val CrunchyShapes = Shapes(
    extraSmall = RoundedCornerShape(4.dp),
    small = RoundedCornerShape(8.dp),
    medium = RoundedCornerShape(12.dp),
    large = RoundedCornerShape(16.dp),   // posters & cards
    extraLarge = RoundedCornerShape(24.dp) // buttons
)

// Convenience aliases used by components
val PosterShape = RoundedCornerShape(16.dp)
val CardShape = RoundedCornerShape(16.dp)
val ButtonShape = RoundedCornerShape(24.dp)
val ChipShape = RoundedCornerShape(50) // full
val BannerShape = RoundedCornerShape(0.dp) // full-bleed hero
val ProgressBarShape = RoundedCornerShape(2.dp)
