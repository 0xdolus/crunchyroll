package com.crunchyroll.ui.theme

import androidx.compose.ui.graphics.Color

// Crunchyroll brand + neutral surfaces (locked)
val CrunchyOrange = Color(0xFFF47521)
val CrunchyOrangeDark = Color(0xFFD65A0F)
val CrunchyOrangeLight = Color(0xFFFF8A3D)

val Background = Color(0xFF000000)
val Surface = Color(0xFF121212)
val SurfaceVariant = Color(0xFF1E1E1E)
val SurfaceElevated = Color(0xFF2A2A2A)

val TextPrimary = Color(0xFFFFFFFF)
val TextSecondary = Color(0xFFB7B7B7)
val TextTertiary = Color(0xFF8A8A8A)
val TextDisabled = Color(0xFF5A5A5A)

val OnPrimary = Color(0xFF000000)
val Error = Color(0xFFCF6679)
val Success = Color(0xFF4CAF50)

// Progress / accent helpers
val ProgressTrack = Color(0xFF333333)
val Divider = Color(0xFF2C2C2C)
val Scrim = Color(0x99000000)
