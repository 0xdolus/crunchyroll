package com.crunchyroll.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

private val CrunchyDarkColorScheme = darkColorScheme(
    primary = CrunchyOrange,
    onPrimary = OnPrimary,
    primaryContainer = CrunchyOrangeDark,
    onPrimaryContainer = TextPrimary,
    secondary = CrunchyOrangeLight,
    onSecondary = OnPrimary,
    secondaryContainer = SurfaceVariant,
    onSecondaryContainer = TextPrimary,
    tertiary = CrunchyOrange,
    onTertiary = OnPrimary,
    background = Background,
    onBackground = TextPrimary,
    surface = Surface,
    onSurface = TextPrimary,
    surfaceVariant = SurfaceVariant,
    onSurfaceVariant = TextSecondary,
    error = Error,
    onError = TextPrimary,
    outline = Divider,
    outlineVariant = SurfaceElevated,
    scrim = Scrim
)

/**
 * Application-wide Material 3 dark theme wrapper.
 * Always forces the Crunchyroll dark aesthetic regardless of system setting.
 */
@Composable
fun CrunchyTheme(
    darkTheme: Boolean = true, // locked to dark
    content: @Composable () -> Unit
) {
    val colorScheme = CrunchyDarkColorScheme

    CompositionLocalProvider(
        LocalSpacing provides Spacing
    ) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = CrunchyTypography,
            shapes = CrunchyShapes,
            content = content
        )
    }
}

// Optional local for spacing if components want to read it via CompositionLocal
val LocalSpacing = staticCompositionLocalOf { Spacing }
