package com.crunchyroll.ui.theme

import androidx.compose.ui.unit.dp

/**
 * Elevation tokens for surfaces and cards.
 * Dark theme keeps elevations low for a flat cinematic feel.
 */
object Elevation {
    val none = 0.dp
    val level1 = 1.dp
    val level2 = 3.dp
    val level3 = 6.dp
    val level4 = 8.dp
    val level5 = 12.dp

    // Semantic
    val card = level1
    val raisedCard = level2
    val bottomBar = level3
    val dialog = level4
    val fab = level5
}
