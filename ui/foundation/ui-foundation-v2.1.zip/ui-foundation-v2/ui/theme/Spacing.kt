package com.crunchyroll.ui.theme

import androidx.compose.ui.unit.dp

/**
 * Spacing tokens (4 / 8 / 12 / 16 / 24 / 32 dp)
 */
object Spacing {
    val xxs = 4.dp
    val xs = 8.dp
    val sm = 12.dp
    val md = 16.dp
    val lg = 24.dp
    val xl = 32.dp

    // Semantic aliases
    val screenHorizontal = md
    val sectionVertical = lg
    val cardGap = sm
    val posterGap = xs
    val contentPadding = md
}
