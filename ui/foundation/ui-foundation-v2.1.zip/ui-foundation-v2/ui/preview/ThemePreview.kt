package com.crunchyroll.ui.preview

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.crunchyroll.ui.components.BottomNavBar
import com.crunchyroll.ui.components.BottomNavDestination
import com.crunchyroll.ui.components.EpisodeCard
import com.crunchyroll.ui.components.HeroBanner
import com.crunchyroll.ui.components.PosterCard
import com.crunchyroll.ui.components.PosterSkeleton
import com.crunchyroll.ui.components.SectionHeader
import com.crunchyroll.ui.theme.Background
import com.crunchyroll.ui.theme.CrunchyTheme
import com.crunchyroll.ui.theme.Spacing
import com.crunchyroll.ui.theme.TextPrimary

/**
 * Compose previews for GitHub Actions / Android Studio.
 * Catches UI regressions before backend integration.
 */
@Preview(showBackground = true, backgroundColor = 0xFF000000, heightDp = 900)
@Composable
fun FullFoundationPreview() {
    CrunchyTheme {
        Scaffold(
            bottomBar = {
                BottomNavBar(
                    currentDestination = BottomNavDestination.Home,
                    onNavigate = {}
                )
            },
            containerColor = Background
        ) { padding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .background(Background)
            ) {
                HeroBanner(
                    title = "Solo Leveling",
                    imageUrl = null,
                    genres = listOf("Action", "Fantasy", "Adventure"),
                    onPlayClick = {}
                )

                Spacer(modifier = Modifier.height(Spacing.md))

                SectionHeader(title = "Continue Watching", onClick = {})

                EpisodeCard(
                    episodeNumber = 12,
                    title = "The Strongest Hunter of All Mankind",
                    runtime = "24m",
                    imageUrl = null,
                    progress = 0.65f,
                    modifier = Modifier.padding(horizontal = Spacing.md)
                )

                Spacer(modifier = Modifier.height(Spacing.md))

                SectionHeader(title = "Popular This Season", onClick = {})

                LazyRow(
                    contentPadding = PaddingValues(horizontal = Spacing.md),
                    horizontalArrangement = Arrangement.spacedBy(Spacing.xs)
                ) {
                    items(listOf("Frieren", "Jujutsu Kaisen", "One Piece", "Demon Slayer")) { title ->
                        PosterCard(title = title, imageUrl = null)
                    }
                }

                Spacer(modifier = Modifier.height(Spacing.lg))

                SectionHeader(title = "Loading State")

                LazyRow(
                    contentPadding = PaddingValues(horizontal = Spacing.md),
                    horizontalArrangement = Arrangement.spacedBy(Spacing.xs)
                ) {
                    items(4) {
                        PosterSkeleton()
                    }
                }
            }
        }
    }
}

@Preview(showBackground = true, backgroundColor = 0xFF000000)
@Composable
fun PosterCardPreview() {
    CrunchyTheme {
        PosterCard(
            title = "Attack on Titan",
            imageUrl = null,
            modifier = Modifier.padding(16.dp)
        )
    }
}

@Preview(showBackground = true, backgroundColor = 0xFF000000)
@Composable
fun BottomNavPreview() {
    CrunchyTheme {
        BottomNavBar(
            currentDestination = BottomNavDestination.Browse,
            onNavigate = {}
        )
    }
}
