# ui-foundation-v2

Crunchyroll-style Material 3 design system for the Android app.

## Package layout

```
ui/
├── theme/
│   ├── Color.kt          # Brand + surface tokens
│   ├── Typography.kt     # Display → Caption scale
│   ├── Shapes.kt         # 16dp posters, 24dp buttons, full chips
│   ├── Spacing.kt        # 4 / 8 / 12 / 16 / 24 / 32 dp
│   ├── Elevation.kt      # Card / surface elevations
│   └── Theme.kt          # CrunchyTheme() Material 3 dark wrapper
├── components/
│   ├── PosterCard.kt     # Fixed 2:3 anime poster
│   ├── HeroBanner.kt     # Featured banner + play CTA
│   ├── EpisodeCard.kt    # Landscape ep + progress
│   ├── SectionHeader.kt  # "Continue Watching ›"
│   ├── BottomNavBar.kt   # 5 tabs (Home / Browse / Search / Lists / Account)
│   └── LoadingSkeleton.kt# Shimmer placeholders
└── preview/
    └── ThemePreview.kt   # Compose previews for CI / Studio
```

## Design tokens (locked)

| Token           | Value     |
|-----------------|-----------|
| Primary         | `#F47521` |
| Background      | `#000000` |
| Surface         | `#121212` |
| Surface Variant | `#1E1E1E` |
| Text Primary    | White     |
| Text Secondary  | `#B7B7B7` |

## Checklist status

- [x] Theme.kt compiles and applies Material 3 dark theme
- [x] Color.kt contains only Crunchyroll brand colors and neutral surfaces
- [x] Typography scale defined for Hero, Title, Body, Caption
- [x] Spacing tokens (4/8/12/16/24/32dp) exist
- [x] Shapes centralized (16dp cards, 24dp buttons, full chips)
- [x] BottomNavBar renders 5 tabs
- [x] PosterCard uses fixed 2:3 aspect ratio
- [x] HeroBanner supports title, genres, play button, gradient overlay
- [x] EpisodeCard supports thumbnail, episode number, runtime, progress bar
- [x] LoadingSkeleton exists for API loading states
- [x] ThemePreview.kt included for Compose previews / GitHub Actions

## Usage

```kotlin
CrunchyTheme {
    // your screens
}
```

Drop these files into your Android project under the matching package (`com.crunchyroll.ui...`).  
Requires Coil for image loading (`io.coil-kt:coil-compose`).

Only after this foundation is integrated should `HomeScreen.kt` be built.
