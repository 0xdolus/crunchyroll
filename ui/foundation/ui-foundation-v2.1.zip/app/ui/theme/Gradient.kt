package com.crunchyroll.ui.theme

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

object CrunchyGradients {
    val HeroOverlay = Brush.verticalGradient(
        listOf(Color.Transparent, Color.Black)
    )
}
