package com.crunchyroll.ui.theme

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween

object CrunchyAnimation {
    val Fast = tween<Int>(180, easing = FastOutSlowInEasing)
    val Normal = tween<Int>(280, easing = FastOutSlowInEasing)
    val Slow = tween<Int>(420, easing = FastOutSlowInEasing)
}
