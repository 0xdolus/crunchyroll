package com.crunchyroll.ui.theme

import androidx.compose.ui.unit.dp

object CrunchyDimens {
    val HeroHeight = 220.dp
    val PosterWidth = 120.dp
    val PosterHeight = 180.dp
    val EpisodeCardHeight = 96.dp
    val TopBarHeight = 64.dp
    val BottomNavHeight = 72.dp
}
