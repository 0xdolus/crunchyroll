package com.crunchyroll.ui.theme

object CrunchyZ {
    const val HeroOverlay = 2f
    const val TopBar = 10f
    const val BottomSheet = 20f
    const val PlayerControls = 30f
}
