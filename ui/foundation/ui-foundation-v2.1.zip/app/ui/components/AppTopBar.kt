package com.crunchyroll.ui.components
// Reusable Crunchyroll top bar placeholder
