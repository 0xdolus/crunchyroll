package com.crunchyroll.ui.components
// Coil AsyncImage wrapper placeholder
