package com.crunchyroll.ui.screens.home
class HomeViewModel {
  val uiState: HomeUiState = HomeUiState.Loading
}
