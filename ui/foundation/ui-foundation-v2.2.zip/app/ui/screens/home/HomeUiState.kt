package com.crunchyroll.ui.screens.home
sealed interface HomeUiState { object Loading: HomeUiState; object Empty: HomeUiState; data class Success(val sections:Int=0): HomeUiState; data class Error(val message:String): HomeUiState }
