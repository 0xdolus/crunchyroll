package com.crunchyroll.ui.screens.home
object HomePreviewData {
  const val heroTitle = "Solo Leveling"
  val continueWatching = listOf("Episode 12","Episode 11","Episode 10")
  val trending = listOf("Dandadan","Kaiju No. 8","One Piece")
}
